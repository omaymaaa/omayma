#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "condidat.h"
#include "poste.h"
#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pb_ajouter_clicked();

    void on_pb_supprimer_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_modifier_clicked();

    void on_pushButton_10_clicked();

    void on_valider1_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_pdf_clicked();


    void on_pushButton_tri_clicked();

    void on_buttonBox_2_accepted();

    void on_pushButton_9_clicked();



    void on_modifier1_clicked();

    void on_pushButton_pdfP_clicked();

    void on_pushButton_4_clicked();

    void on_stat_clicked();

    void on_comboBox_supp_activated(const QString &arg1);

private:
    Ui::MainWindow *ui;
    Condidat tmpCondidat;
    Poste tmpPoste;
};

#endif // MAINWINDOW_H
