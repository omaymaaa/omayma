#include "poste.h"
#include <QDebug>
#include "connexion.h"
Poste::Poste()
{
id="";
nom="";
tel=0;
mail="";
}
Poste::Poste(QString id,QString nom,long tel,QString mail)
{
  this->id=id;
  this->nom=nom;
  this->tel=tel;
  this->mail=mail;
}
QString Poste::get_nom(){return  nom;}
long Poste::get_tel(){return tel;}
QString Poste::get_mail(){return mail;}


QString Poste::get_id(){return  id;}

bool Poste::ajouter()
{
QSqlQuery query;

query.prepare("INSERT INTO POSTE (ID,NOM,TEL,MAIL) "
                    "VALUES (:id,:nom,:tel,:mail)");
QString res= QString::number(tel);

query.bindValue(":id",id);
query.bindValue(":nom",nom);
query.bindValue(":tel",res);
query.bindValue(":mail",mail);


return    query.exec();
}

QSqlQueryModel * Poste::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from POSTE");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("tel"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("mail"));

    return model;
}
QSqlQueryModel * Poste::tri()
{QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from POSTE ORDER BY NOM ASC");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("tel"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("mail"));

    return model;
}

bool Poste::supprimer(QString id)
{
QSqlQuery query;
query.prepare("Delete from poste where id = :id ");
query.bindValue(":id", id);
return    query.exec();
}

bool Poste::modifier()

 {      QSqlQuery query;
        QString res= QString::number(tel);

        query.prepare("update POSTE set ID=:id,NOM=:nom,tel=:tel,MAIL=:mail where ID=:id");
        query.bindValue(":id",id);
        query.bindValue(":nom",nom);
            query.bindValue(":tel", res);
        query.bindValue(":mail", mail);
        return    query.exec();
}

bool Poste::testMail(QString mail){

    int test=0;

    for(int i = 0; i < mail.size(); i++) {

if(mail[i]=="@")

{test++;



}}

    for(int i = 0; i < mail.size(); i++) {

if((test==1)&&(mail[i]=="."))

{if(mail.size()>i+1)

    return true;

}}

return false;}
bool Poste::testNumber(QString number){



    if(number.size()==8)

        return true;

    return false;




}






QSqlQueryModel * Poste::rechercher2(QString e )
{
    QSqlQueryModel * model= new QSqlQueryModel();
        model->setQuery("SELECT * FROM POSTE WHERE NOM ='"+e+"' ;");
        model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
        model->setHeaderData(1, Qt::Horizontal, QObject::tr("NOM"));
        model->setHeaderData(2, Qt::Horizontal, QObject::tr("TEL"));
        model->setHeaderData(3, Qt::Horizontal, QObject::tr("MAIL"));

    return model ;
}



