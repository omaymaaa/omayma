#include "condidat.h"
#include <QDebug>
#include "connexion.h"
Condidat::Condidat()
{
cin="";
nom="";
prenom="";
//tel=0;
 mail="";
 //age=0
}
Condidat::Condidat(QString cin,QString nom,QString prenom,QString mail,long tel,int age)
{
  this->cin=cin;
  this->nom=nom;
  this->prenom=prenom;
  this->mail=mail;
  this->tel=tel;
  this->age=age;
}
QString Condidat::get_nom(){return  nom;}
QString Condidat::get_prenom(){return prenom;}
QString Condidat::get_mail(){return mail;}
long Condidat::get_tel(){return tel;}

QString Condidat::get_cin(){return  cin;}
int Condidat::get_age(){return age;}
bool Condidat::ajouter()
{
QSqlQuery query;

query.prepare("INSERT INTO CONDIDAT (CIN,NOM,PRENOM,MAIL,TEL,AGE) "
                    "VALUES (:cin,:nom,:prenom,:mail,:tel,:age)");
QString res= QString::number(tel);

query.bindValue(":cin",cin);
query.bindValue(":nom",nom);
query.bindValue(":prenom",prenom);
query.bindValue(":mail",mail);
query.bindValue(":tel",res);

query.bindValue(":age",age);
return    query.exec();
}

QSqlQueryModel * Condidat::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from Condidat");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("cin"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("mail"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("tel"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("age"));

    return model;
}
QSqlQueryModel * Condidat::tri()
{QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from Condidat ORDER BY NOM ASC");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("cin"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("mail"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("tel"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("age"));

    return model;
}

bool Condidat::supprimer(QString cin)
{
QSqlQuery query;
query.prepare("Delete from condidat where CIN = :cin ");
query.bindValue(":cin", cin);
return    query.exec();
}

bool Condidat::modifier()

 {      QSqlQuery query;
        QString res= QString::number(tel);

        query.prepare("update CONDIDAT set CIN=:cin,NOM=:nom,PRENOM=:prenom,MAIL=:mail,TEL=:tel,AGE=:age where CIN=:cin");
        query.bindValue(":cin",cin);
        query.bindValue(":nom",nom);
        query.bindValue(":prenom",prenom);
        query.bindValue(":mail", mail);
        query.bindValue(":tel", res);
        query.bindValue(":age", age);
        return    query.exec();
}

bool Condidat::testMail(QString mail){

    int test=0;

    for(int i = 0; i < mail.size(); i++) {

if(mail[i]=="@")

{test++;



}}

    for(int i = 0; i < mail.size(); i++) {

if((test==1)&&(mail[i]=="."))

{if(mail.size()>i+1)

    return true;

}}

return false;}



bool Condidat::testNumber(QString number){



    if(number.size()==8)

        return true;

    return false;




}

bool Condidat::testCin(QString cin){

    if(cin.size()!=8)

    return false;



    for(int i = 0; i < cin.size(); i++) {



    if (!(cin[i] >= '0' && cin[i] <= '9'))

        return false;



}

    return true;



}

QSqlQueryModel * Condidat::rechercher1(QString e )
{
    QSqlQueryModel * model= new QSqlQueryModel();
        model->setQuery("SELECT * FROM CONDIDAT WHERE NOM ='"+e+"' ;");
        model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
        model->setHeaderData(1, Qt::Horizontal, QObject::tr("NOM"));
        model->setHeaderData(2, Qt::Horizontal, QObject::tr("PRENOM"));
        model->setHeaderData(3, Qt::Horizontal, QObject::tr("MAIL"));
        model->setHeaderData(4, Qt::Horizontal, QObject::tr("TEL"));
         model->setHeaderData(5, Qt::Horizontal, QObject::tr("AGE"));

    return model ;
}



