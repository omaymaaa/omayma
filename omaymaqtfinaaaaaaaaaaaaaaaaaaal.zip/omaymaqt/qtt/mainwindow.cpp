#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "condidat.h"
#include <QMessageBox>
#include "connexion.h"
#include <QPainter>
#include <QPdfWriter>
#include <QDesktopServices>
#include <QUrl>
#include <QPainter>
#include <QPrintDialog>
#include <QPieSlice>
#include <QPieSeries>
#include <QtCharts/QChartView>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
QT_CHARTS_USE_NAMESPACE

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
ui->setupUi(this);

ui->tabCondidat->setModel(tmpCondidat.afficher());
ui->modifierCIN->setModel(tmpCondidat.afficher());
ui->tabPoste->setModel(tmpPoste.afficher());
ui->comboBox_2->setModel(tmpPoste.afficher());
ui->comboBox_supp->setModel(tmpPoste.afficher());

ui->comboBox->setModel(tmpCondidat.afficher());





}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pb_ajouter_clicked()
{
    QString cin = ui->lineEdit_cin_2->text();
    QString nom= ui->lineEdit_nom->text();
    QString prenom= ui->lineEdit_prenom_2->text();
    QString mail= ui->lineEdit_mail_2->text();
    long tel= ui->lineEdit_tel_2->text().toLong();
    int age=ui->lineEdit_age->text().toInt();
    Condidat e(cin,nom,prenom,mail,tel,age);

    if (e.testCin(ui->lineEdit_cin_2->text())==false)

             {



                 QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP CIN!!!!") ;

                 QMessageBox::critical(0, qApp->tr("Ajout"),



                                 qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);



             }

                    else if (ui->lineEdit_nom->text().isEmpty())

                     {



                         QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP NOM!!!!") ;

                         QMessageBox::critical(0, qApp->tr("Ajout"),



                                         qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);



                     }
    else if (ui->lineEdit_age->text().isEmpty())

     {



         QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP AGE!!!!") ;

         QMessageBox::critical(0, qApp->tr("Ajout"),



                         qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);



     }


                      else if (ui->lineEdit_prenom_2->text().isEmpty())

                       {



                           QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP PRENOM!!!!") ;

                           QMessageBox::critical(0, qApp->tr("Ajout"),



                                           qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);



                       }





                else if (e.testMail(ui->lineEdit_mail_2->text())==false)

                       {



                           QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP MAIL!!!!") ;

                           QMessageBox::critical(0, qApp->tr("Ajout"),



                                           qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);



                       }

    else if (e.testNumber(ui->lineEdit_tel_2->text())==false)

           {



               QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP Number!!!!") ;

               QMessageBox::critical(0, qApp->tr("Ajout"),



                               qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);



           }







            else {

  bool test=e.ajouter();
  if(test)
{

      ui->tabCondidat->setModel(tmpCondidat.afficher());//refresh
      ui->modifierCIN->setModel(tmpCondidat.afficher());

QMessageBox::information(nullptr, QObject::tr("Ajouter un condidat"),
                  QObject::tr("Condidat ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un condidat"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);


}}



void MainWindow::on_pushButton_clicked()
{

    QString cin=ui->comboBox_2->currentText();

    bool test=tmpCondidat.supprimer(cin);
    if(test)
    {
        ui->tabPoste->setModel(tmpPoste.afficher());
        ui->comboBox_2->setModel(tmpPoste.afficher());
        QMessageBox::information(nullptr, QObject::tr("Supprimer un poste"),
                    QObject::tr("poste supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un condidat"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_pushButton_2_clicked()
{
    QString cin=ui->modifierCIN->currentText();

    bool test=tmpCondidat.supprimer(cin);
    if(test)
    {
        ui->tabCondidat->setModel(tmpCondidat.afficher());
        ui->modifierCIN->setModel(tmpCondidat.afficher());
        QMessageBox::information(nullptr, QObject::tr("Supprimer un condidat"),
                    QObject::tr("condidat supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un condidat"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}



void MainWindow::on_modifier_clicked()
{
    QString cin=ui->modifierCIN->currentText();
    QString nom = ui->modifierNOM->text();
    QString prenom = ui->modifierPrenom->text();
    QString mail = ui->modifierMail->text();
    long tel = ui->modifierTel->text().toLong();

int age = ui->modifier_age->text().toInt();
    Condidat con (cin,nom,prenom,mail,tel,age);

            QSqlQuery query;

            bool test=con.modifier();
            if(test)
            {

                ui->tabCondidat->setModel(tmpCondidat.afficher());//refresh




                QMessageBox::information(nullptr, QObject::tr("Modifier condidat"),
                            QObject::tr("condidat Modifier.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);

            }
            else
            {
                QMessageBox::critical(nullptr, QObject::tr("Modifier employé"),
                            QObject::tr("Erreur !.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
            }

            ui->modifierCIN->clear();
            ui->modifierNOM->clear();
            ui->modifierPrenom->clear();
            ui->modifierMail->clear();
            ui->modifierTel->clear();
             ui->modifier_age->clear();



}




void MainWindow::on_valider1_clicked()
{
    {
        QString cin=ui->modifierCIN->currentText();
                  QSqlQuery query;
                  query.prepare("select * from CONDIDAT where CIN='"+cin+"'");
                  if (query.exec())
                  {
                   while (query.next())
                   {    //ui->comboBox_4->setModel(tmpveterinaire->afficher());


                       ui->modifierNOM->setText(query.value(1).toString());
                       ui->modifierPrenom->setText(query.value(2).toString());
                       ui->modifierMail->setText(query.value(3).toString());
                       ui->modifierTel->setText(query.value(4).toString());
                        ui->modifier_age->setText(query.value(5).toString());
                   }
                  }
}}

void MainWindow::on_pushButton_3_clicked()
{
    QString nom = ui->recherche_condidat->text();
    ui->tabCondidat->setModel(tmpCondidat.rechercher1(nom));

}

void MainWindow::on_pushButton_pdf_clicked()
{
    //QDateTime datecreation = date.currentDateTime();
    //QString afficheDC = "Date de Creation PDF : " + datecreation.toString() ;
           QPdfWriter pdf("C:/Users/user/Desktop/Pdf.pdf");
           QPainter painter(&pdf);
          int i = 4000;
               painter.setPen(Qt::blue);
               painter.setFont(QFont("Arial", 30));
               painter.drawText(1100,1200,"Liste Des Condidats");
               painter.setPen(Qt::black);
               painter.setFont(QFont("Arial", 50));
              // painter.drawText(1100,2000,afficheDC);
               painter.drawRect(100,100,7300,2600);
               //painter.drawPixmap(QRect(7600,70,2000,2600),QPixmap("C:/Users/RH/Desktop/projecpp/image/logopdf.png"));
               painter.drawRect(0,3000,9600,500);
               painter.setFont(QFont("Arial", 9));
               painter.drawText(200,3300,"CIN");
               painter.drawText(1700,3300,"NOM");
               painter.drawText(3200,3300,"PRENOM");
               painter.drawText(4900,3300,"MAIL");
               painter.drawText(6600,3300,"TEL");

               QSqlQuery query;
               query.prepare("select * from CONDIDAT");
               query.exec();
               while (query.next())
               {
                   painter.drawText(200,i,query.value(0).toString());
                   painter.drawText(1700,i,query.value(1).toString());
                   painter.drawText(3200,i,query.value(2).toString());
                   painter.drawText(4900,i,query.value(3).toString());
                   painter.drawText(6600,i,query.value(4).toString());
                  i = i + 700;
               }
               int reponse = QMessageBox::question(this, "Génerer PDF", "<PDF Enregistré>...Vous Voulez Affichez Le PDF ?", QMessageBox::Yes |  QMessageBox::No);
                   if (reponse == QMessageBox::Yes)
                   {
                       QDesktopServices::openUrl(QUrl::fromLocalFile("C:/Users/user/Desktop/Pdf.pdf"));
                       painter.end();
                   }
                   if (reponse == QMessageBox::No)
                   {
                        painter.end();
                   }
}



void MainWindow::on_pushButton_tri_clicked()
{
    ui->tabCondidat->setModel(tmpCondidat.tri());

}

void MainWindow::on_buttonBox_2_accepted()
{
    QString id = ui->lineEdit_id->text();
    QString nom= ui->lineEdit_nom_3->text();
    long tel= ui->lineEdit_telP->text().toLong();
    QString mail= ui->lineEdit_mail_3->text();
    Poste e(id,nom,tel,mail);



                     if (ui->lineEdit_nom_3->text().isEmpty())

                     {



                         QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP NOM!!!!") ;

                         QMessageBox::critical(0, qApp->tr("Ajout"),



                                         qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);



                     }

                    else if (ui->lineEdit_id->text().isEmpty())

                     {



                         QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP ID!!!!") ;

                         QMessageBox::critical(0, qApp->tr("Ajout"),



                                         qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);



                     }

                          else if (e.testNumber(ui->lineEdit_telP->text())==false)

           {



               QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP Number!!!!") ;

               QMessageBox::critical(0, qApp->tr("Ajout"),



                               qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);



           }
                     else if (e.testMail(ui->lineEdit_mail_3->text())==false)

                            {



                                QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP MAIL!!!!") ;

                                QMessageBox::critical(0, qApp->tr("Ajout"),



                                                qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);



                            }








            else {

  bool test=e.ajouter();
  if(test)
{

      ui->tabPoste->setModel(tmpPoste.afficher());//refresh
      ui->comboBox_2->setModel(tmpPoste.afficher());

QMessageBox::information(nullptr, QObject::tr("Ajouter un condidat"),
                  QObject::tr("Condidat ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un condidat"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);


}}

    void MainWindow::on_modifier1_clicked()
    {
        QString id=ui->comboBox_2->currentText();
        QString nom = ui->lineEdit_nom_2->text();
        long tel = ui->lineEdit_tel->text().toLong();
        QString mail = ui->lineEdit_mail->text();


        Poste Pos (id,nom,tel,mail);

                QSqlQuery query;

                bool test=Pos.modifier();
                if(test)
                {

                    ui->tabPoste->setModel(tmpPoste.afficher());//refresh




                    QMessageBox::information(nullptr, QObject::tr("Modifier poste"),
                                QObject::tr("poste Modifier.\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);

                }
                else
                {
                    QMessageBox::critical(nullptr, QObject::tr("Modifier poste"),
                                QObject::tr("Erreur !.\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);
                }

                ui->comboBox_2->clear();
                ui->lineEdit_nom_2->clear();
                ui->lineEdit_tel->clear();
                ui->lineEdit_mail->clear();


    }




void MainWindow::on_pushButton_9_clicked()
{
    {
        QString id=ui->comboBox_2->currentText();
                  QSqlQuery query;
                  query.prepare("select * from POSTE where ID='"+id+"'");
                  if (query.exec())
                  {
                   while (query.next())
                   {    //ui->comboBox_4->setModel(tmpveterinaire->afficher());


                       ui->lineEdit_nom_2->setText(query.value(1).toString());
                       ui->lineEdit_tel->setText(query.value(2).toString());
                       ui->lineEdit_mail->setText(query.value(3).toString());
                   }
                  }
}
}

void MainWindow::on_pushButton_10_clicked()
{
    QString id=ui->comboBox_2->currentText();
    QString nom = ui->lineEdit_nom_2->text();
    long tel = ui->lineEdit_tel->text().toLong();
    QString mail = ui->lineEdit_mail->text();


    Poste Pos (id,nom,tel,mail);

            QSqlQuery query;

            bool test=Pos.modifier();
            if(test)
            {


                ui->tabPoste->setModel(tmpPoste.afficher());
                ui->comboBox_2->setModel(tmpPoste.afficher());




            }
            else
            {
                QMessageBox::critical(nullptr, QObject::tr("Modifier employé"),
                            QObject::tr("Erreur !.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
            }

            ui->lineEdit_nom_2->clear();
            ui->lineEdit_tel->clear();
            ui->lineEdit_mail->clear();

}

void MainWindow::on_pushButton_pdfP_clicked()
{
    //QDateTime datecreation = date.currentDateTime();
    //QString afficheDC = "Date de Creation PDF : " + datecreation.toString() ;
           QPdfWriter pdf("C:/Users/user/Desktop/Pdfp.pdf");
           QPainter painter(&pdf);
          int i = 4000;
               painter.setPen(Qt::blue);
               painter.setFont(QFont("Arial", 30));
               painter.drawText(1100,1200,"Liste Des postes");
               painter.setPen(Qt::black);
               painter.setFont(QFont("Arial", 50));
              // painter.drawText(1100,2000,afficheDC);
               painter.drawRect(100,100,7300,2600);
               //painter.drawPixmap(QRect(7600,70,2000,2600),QPixmap("C:/Users/RH/Desktop/projecpp/image/logopdf.png"));
               painter.drawRect(0,3000,9600,500);
               painter.setFont(QFont("Arial", 9));
               painter.drawText(200,3300,"ID");
               painter.drawText(1700,3300,"NOM");
               painter.drawText(3200,3300,"TEL");
               painter.drawText(4900,3300,"MAIL");

               QSqlQuery query;
               query.prepare("select * from POSTE");
               query.exec();
               while (query.next())
               {
                   painter.drawText(200,i,query.value(0).toString());
                   painter.drawText(1700,i,query.value(1).toString());
                   painter.drawText(3200,i,query.value(2).toString());
                   painter.drawText(4900,i,query.value(3).toString());
                  i = i + 700;
               }
               int reponse = QMessageBox::question(this, "Génerer PDF", "<PDF Enregistré>...Vous Voulez Affichez Le PDF ?", QMessageBox::Yes |  QMessageBox::No);
                   if (reponse == QMessageBox::Yes)
                   {
                       QDesktopServices::openUrl(QUrl::fromLocalFile("C:/Users/user/Desktop/Pdfp.pdf"));
                       painter.end();
                   }
                   if (reponse == QMessageBox::No)
                   {
                        painter.end();
                   }



}

void MainWindow::on_pushButton_4_clicked()
{

    QString nom = ui->recherche_condidat_2->text();
    ui->tabPoste->setModel(tmpPoste.rechercher2(nom));
}

void MainWindow::on_stat_clicked()
{

        QSqlQueryModel * model= new QSqlQueryModel();
            model->setQuery("select * from condidat where age < 20 ");
            float age=model->rowCount();
            model->setQuery("select * from condidat where age between 20 and 30 ");
            float age2=model->rowCount();
            model->setQuery("select * from age where age>30 ");
            float age3=model->rowCount();
            float total=age+age2+age3;
            QString a=QString("moins de 20 "+QString::number((age*100)/total,'f',2)+"%" );
            QString b=QString("entre 20 et 30 "+QString::number((age2*100)/total,'f',2)+"%" );
            QString c=QString("+30 "+QString::number((age3*100)/total,'f',2)+"%" );
            QPieSeries *series = new QPieSeries();
            series->append(a,age);
            series->append(b,age2);
            series->append(c,age3);
    if (age!=0)
    {QPieSlice *slice = series->slices().at(0);
     slice->setLabelVisible();
     slice->setPen(QPen());}
    if ( age2!=0)
    {
             // Add label, explode and define brush for 2nd slice
             QPieSlice *slice1 = series->slices().at(1);
             //slice1->setExploded();
             slice1->setLabelVisible();
    }
    if(age3!=0)
    {
             // Add labels to rest of slices
             QPieSlice *slice2 = series->slices().at(2);
             //slice1->setExploded();
             slice2->setLabelVisible();
    }
            // Create the chart widget
            QChart *chart = new QChart();
            // Add data to chart with title and hide legend
            chart->addSeries(series);
            chart->setTitle("Pourcentage Par Age:totale de "+ QString::number(total));
            chart->legend()->hide();
            // Used to display the chart
            QChartView *chartView = new QChartView(chart);
            chartView->setRenderHint(QPainter::Antialiasing);
            chartView->resize(1000,500);
            chartView->show();
    }

