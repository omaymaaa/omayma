#ifndef CONDIDAT_H
#define CONDIDAT_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
class Condidat
{public:
    Condidat();
    Condidat(QString,QString,QString,QString,long,int);
    QString get_nom();
    QString get_prenom();
    QString get_cin();
    QString get_mail();

    long get_tel();
    int get_age();

    bool ajouter();
    bool modifier();
    bool testMail(QString );
    bool testCin(QString );
    bool testNumber(QString);

    QSqlQueryModel * rechercher1(QString);


    QSqlQueryModel * afficher();
    QSqlQueryModel * tri();

    bool supprimer(QString);
private:
    QString nom,prenom,cin,mail;
     long tel;
     int age;
};

#endif // CONDIDAT_H
