#ifndef POSTE_H
#define POSTE_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
class Poste
{public:
    Poste();
    Poste(QString,QString,long,QString);
    QString get_id();
    QString get_nom();
    long get_tel();
    QString get_mail();

    bool ajouter();
    bool modifier();
    bool testMail(QString );
    bool testNumber(QString);
    QSqlQueryModel * rechercher2(QString);



    QSqlQueryModel * afficher();
    QSqlQueryModel * tri();

    bool supprimer(QString);
private:
    QString id,nom,mail;
     long tel;
};


#endif // POSTE_H
