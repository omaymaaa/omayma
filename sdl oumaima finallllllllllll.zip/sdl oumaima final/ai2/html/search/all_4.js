var searchData=
[
  ['scroll_2ec',['scroll.c',['../scroll_8c.html',1,'']]],
  ['scrolling_2ec',['scrolling.c',['../scrolling_8c.html',1,'']]],
  ['scrollingleft',['scrollingleft',['../deplacement_8h.html#a8d14bf67a9e64e02d200d4bbcb88549d',1,'scrollingleft(SDL_Rect *rect, SDL_Rect *positionFond):&#160;scroll.c'],['../scroll_8c.html#a8d14bf67a9e64e02d200d4bbcb88549d',1,'scrollingleft(SDL_Rect *rect, SDL_Rect *positionFond):&#160;scroll.c']]],
  ['scrollingright',['scrollingright',['../deplacement_8h.html#aa765dbfe8864144399be8658b5c92e69',1,'scrollingright(SDL_Rect *rect, SDL_Rect *positionFond):&#160;scroll.c'],['../scroll_8c.html#aa765dbfe8864144399be8658b5c92e69',1,'scrollingright(SDL_Rect *rect, SDL_Rect *positionFond):&#160;scroll.c']]]
];
