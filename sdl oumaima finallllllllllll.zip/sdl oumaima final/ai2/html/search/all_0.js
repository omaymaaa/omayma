var searchData=
[
  ['animate',['animate',['../deplacement_8h.html#aeb78bf444395619f4699f9a74b20d6ac',1,'animate(SDL_Surface *screen, SDL_Surface *Background, SDL_Surface *image2, SDL_Rect *positionFond, int *running):&#160;scrolling.c'],['../scrolling_8c.html#aeb78bf444395619f4699f9a74b20d6ac',1,'animate(SDL_Surface *screen, SDL_Surface *Background, SDL_Surface *image2, SDL_Rect *positionFond, int *running):&#160;scrolling.c']]]
];
